# Installation

Install yarn.
If needed, run this command with administrator privileges or sudo:
`yarn install`
Run the script with:
`yarn start`
It may be required to allow more memory to node.js with the option:
`yarn start --max-old-space-size 8000`
