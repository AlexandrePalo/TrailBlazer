# Front end application

## Installation

### Preleminaries

Be sure to have NodeJs and yarn installed (or npm).

### Packages installation

#### Install serve package

* `yarn global add serve` (or `npm install -g serve`). If needed, run this
  command with administrator privileges or sudo.
